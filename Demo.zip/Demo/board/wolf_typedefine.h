/********************************************************************
filename : wolf_typedefine.h
discript : define some type whitch not declared in lib.
version  : V0.0
editor   : Icy - dreamwolf
time     : 2014.2.28
statement: This file is modified by dreamwolf under LGPL,you could use 
           it free.We cann't ensure there is no error in this file,and
				   if you detect an error please contact us freely,it is so a-
					 ppreciate for your help to improve our code that could help 
					 more people to use it safty.
contact  : dreamwolf66@163.com
           www.zyltek.com
********************************************************************/

#ifndef __WOLF_TYPEDEFINE_H__
#define __WOLF_TYPEDEFINE_H__

#define TRUE						1
#define FALSE						0

#define SUCCESS					1
#define FAIL						0

#endif

